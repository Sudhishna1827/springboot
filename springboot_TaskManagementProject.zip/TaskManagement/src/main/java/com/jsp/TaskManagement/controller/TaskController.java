package com.jsp.TaskManagement.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.jsp.TaskManagement.dao.TaskDao;
import com.jsp.TaskManagement.dto.ResponseStructure;
import com.jsp.TaskManagement.dto.Task;

@RestController
public class TaskController {

	@Autowired
	TaskDao dao;

	// creating REST APIs

	// url --> end point
	// API for inserting Task object into DB

	@PostMapping("/task")
	public ResponseEntity<ResponseStructure<Task>> insertTask(@RequestBody Task task) {
		Task t = dao.addTask(task);

		ResponseStructure<Task> response = new ResponseStructure<Task>();
		response.setStatus(200);
		response.setMessage("Task details stored successfully.");
		response.setData(t);

		return ResponseEntity.ok(response);
	}

	// API to retrieve all task objects from DB
	@GetMapping("/getall")
	public ResponseEntity<ResponseStructure<List<Task>>> getAll() {
		List<Task> tasks = dao.getAllTasks();
		ResponseStructure<List<Task>> response = new ResponseStructure<List<Task>>();
		response.setStatus(200);
		response.setMessage("ALl the tasks fetched successfully.");
		response.setData(tasks);
		return ResponseEntity.ok(response);
	}

	// API to retrieve an object from DB using
	@GetMapping("/get")
	public ResponseEntity<ResponseStructure<Task>> find(@RequestParam int taskid) {
		Task t = dao.findTask(taskid);
		ResponseStructure<Task> response = new ResponseStructure<Task>();
		response.setStatus(200);
		response.setMessage("Task details fetched successfully using task ID.");
		response.setData(t);

		return ResponseEntity.ok(response);
	}

	// API to delete a task object
	@DeleteMapping("/delete")
	public ResponseEntity<ResponseStructure<String>> deleteTask(@RequestParam int taskid) {
		String s = dao.deleteTask(taskid);
		ResponseStructure<String> response = new ResponseStructure<String>();
		response.setStatus(200);
		response.setMessage("Task details deleted using task ID.");
		response.setData(s);

		return ResponseEntity.ok(response);
	}

	// API to update task details
	@PutMapping("/update")
	public ResponseEntity<ResponseStructure<String>> updateTask(@RequestParam int taskid, @RequestParam String status, @RequestParam String description) {
		String s = dao.updateTask(taskid, status, description);
		ResponseStructure<String> response = new ResponseStructure<String>();
		response.setStatus(200);
		response.setMessage("Task status and description updated using task ID.");
		response.setData(s);

		return ResponseEntity.ok(response);
	}

	// API to fetch all completed tasks
	@GetMapping("/completed")
	public ResponseEntity<ResponseStructure<List<Task>>> findAllCompletedTask() {
		List<Task> tasks = dao.getAllCompletedTask();
		ResponseStructure<List<Task>> response = new ResponseStructure<List<Task>>();
		response.setStatus(200);
		response.setMessage("ALl the tasks fetched successfully.");
		response.setData(tasks);
		return ResponseEntity.ok(response);
	}

	// API to fetch Task object based on name
	@GetMapping("/name")
	public ResponseEntity<ResponseStructure<Task>> findTaskByName(@RequestParam String name) {
		Task t = dao.getTaskByName(name);
		
		ResponseStructure<Task> response = new ResponseStructure<Task>();
		response.setStatus(200);
		response.setMessage("Task details fetched successfully using task name.");
		response.setData(t);

		return ResponseEntity.ok(response);
	}
}
