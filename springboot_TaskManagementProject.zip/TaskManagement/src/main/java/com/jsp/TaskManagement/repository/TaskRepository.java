package com.jsp.TaskManagement.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.jsp.TaskManagement.dto.Task;

public interface TaskRepository extends JpaRepository<Task, Integer>
{
	
	@Query("select t from Task t where t.status='completed' ") 
	public List<Task> findAllCompletedTask();
	
	//using SQl query also it is possible : 
	// Query("select * from task where status = 'completed' " , nativeQuery = true)
	
	
	@Query("select t from Task t where t.name = ?1")
	public Task findByName(String name);
}
