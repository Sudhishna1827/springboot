package com.jsp.TaskManagement.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.jsp.TaskManagement.dto.Task;
import com.jsp.TaskManagement.repository.TaskRepository;

@Repository
public class TaskDao {

	@Autowired
	TaskRepository repository;
	
	// to add/insert task object into DB
	public Task addTask(Task task) {	
		repository.save(task);
		return task;
	}
	
	// to retrieve all task objects from DB
	public List<Task> getAllTasks()
	{
		return repository.findAll();
	}
	
	// to retrieve a task object based on primary key(ID) 
	public Task findTask(int taskid)
	{
		Optional<Task> opt = repository.findById(taskid);
		if(opt.isPresent())
		{
			return opt.get();
		}
		return null;
	}
	
	// to delete a task object from DB
	public String deleteTask(int taskid)
	{
		Task t = findTask(taskid);
		if(t != null)
		{
			repository.delete(t);
			return "Task removed successfully..";
		}
		else
			return "Cannot delete ... Task is not found...";
	}
	
	
	// to update status , description based on ID
	public String updateTask(int taskid , String newStatus , String newDescription)
	{
		Task t = findTask(taskid);
		if(t != null)
		{
			t.setStatus(newStatus);
			t.setDescription(newDescription);
			repository.save(t);
			return "task status and description is updated.";
		}
		else
		{
			return "Cannot update ... Task is not found.";
		}
	}
	
	// to retrieve all task objects whose status is completed
	public List<Task> getAllCompletedTask()
	{
		return repository.findAllCompletedTask();
	}
	
	// to find task object using name
	public Task getTaskByName(String name)
	{
		return repository.findByName(name);
	}
}







